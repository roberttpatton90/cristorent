'use strict';

app.controller('MainCtrl', function($scope, $interval) {

    console.log('Starting');
    
    /* Transition */
    var maxImage = 13;
    var paginatorClick = false;
    /*$interval(function() {
        if (paginatorClick == false) {
            if ($scope.PaginationN === maxImage) {
                $scope.PaginationN = 1;
            } else
                $scope.PaginationN++;    
            console.log($scope.PaginationN);            
        }
    }, 5200, maxImage);*/
    
    /* Pagination */
    $scope.PaginationN = 1;
    $scope.Pagination = function(n) {
        $scope.PaginationN = n;
        paginatorClick = true;
    };

    $scope.aeroportShow = false;
    $scope.ShowAeroportInfo = function() {
        $scope.aeroportShow = !$scope.aeroportShow;
        //console.log($scope.aeroportShow);
    };
    $scope.ShowAeroportInfoM = function() {
        $scope.aeroportShow = true;
        var y = 0;
        var i = setInterval(function() {
            $('body').scrollTop(y);
            y++;
            if (y === 735) {
                clearInterval(i);
            }
        }, 0);
    };
    
    $scope.packageShow = false;
    $scope.ShowPackageInfo = function() {
        $scope.packageShow = !$scope.packageShow;
        console.log($scope.packageShow);
    };
    $scope.ShowPackageInfoM = function() {
        $scope.aeroportShow = false;
        $scope.packageShow = true;
        var y = 0;
        var i = setInterval(function() {
            $('body').scrollTop(y);
            y++;
            if (y === 765) {
                clearInterval(i);
            }
        }, 0);
    };    
    

});