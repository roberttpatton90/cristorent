'use strict';

var app = angular.module('App', ['ngRoute']);

app.config(function($routeProvider) {
    $routeProvider.when('/', {
        //templateUrl: 'app/views/'
        controller: 'MainCtrl'
    }).otherwise({
        redirectTo: '/'
    });
});